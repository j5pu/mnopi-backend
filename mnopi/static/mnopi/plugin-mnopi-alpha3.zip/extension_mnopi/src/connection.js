// Server and POST values
//var MNOPI_SERVER_URL = "http://192.168.1.38:8000/";
var MNOPI_SERVER_URL = "https://ec2-54-197-231-98.compute-1.amazonaws.com/"

var POST_SERVICES = {
    'login' : "plugin_login",
    'sendPageVisited' : "sendPageVisited",
    'sendSearch' : "sendSearch",
    'sendHtmlVisited' : "sendHtmlVisited"
};

// Plugin version
PLUGIN_VERSION = "alpha3";
