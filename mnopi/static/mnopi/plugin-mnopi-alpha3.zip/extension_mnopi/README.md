mnopi-plugin
============

Plugin para Chrome de Mnopi
