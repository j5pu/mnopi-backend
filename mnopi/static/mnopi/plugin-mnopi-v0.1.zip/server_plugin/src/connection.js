// Server and POST values
//var MNOPI_SERVER_URL = "http://localhost:8000/";
var MNOPI_SERVER_URL = "http://ec2-184-73-11-181.compute-1.amazonaws.com/";

var POST_SERVICES = {
    'login' : "login",
    'sendPageVisited' : "sendPageVisited",
    'sendSearch' : "sendSearch",
    'sendHtmlVisited' : "sendHtmlVisited"
};
